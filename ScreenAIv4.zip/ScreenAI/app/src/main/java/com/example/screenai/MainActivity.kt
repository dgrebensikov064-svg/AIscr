package com.example.screenai

import android.Manifest
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File

class MainActivity : ComponentActivity() {
    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private lateinit var urlField: EditText
    private lateinit var btnTextField: EditText
    private lateinit var soundSwitch: Switch
    private lateinit var ttsSwitch: Switch
    private lateinit var sizeBar: SeekBar
    private var selectedColor = 0xFF7C5CFF.toInt()

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, OverlayService::class.java)
                    .putExtra("code", r.resultCode)
                    .putExtra("data", data)
                startForegroundService(i)
                moveTaskToBack(true)
            }
        }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            val mpm = getSystemService(MediaProjectionManager::class.java)
            projectionLauncher.launch(mpm.createScreenCaptureIntent())
        }

    private val pickImage =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
            if (uri != null) {
                val ok = saveAvatar(uri)
                Toast.makeText(this, if (ok) "Аватар сохранён" else "Не удалось загрузить фото", Toast.LENGTH_SHORT).show()
            }
        }

    private fun saveAvatar(uri: Uri): Boolean {
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            var sample = 1
            while (bounds.outWidth / sample > 1024 || bounds.outHeight / sample > 1024) sample *= 2
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            val src = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                ?: return false
            val side = minOf(src.width, src.height)
            val square = Bitmap.createBitmap(src, (src.width - side) / 2, (src.height - side) / 2, side, side)
            val scaled = Bitmap.createScaledBitmap(square, 256, 256, true)
            val circle = Bitmap.createBitmap(256, 256, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(circle)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            canvas.drawCircle(128f, 128f, 128f, paint)
            paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
            canvas.drawBitmap(scaled, 0f, 0f, paint)
            File(filesDir, "avatar.png").outputStream().use { circle.compress(Bitmap.CompressFormat.PNG, 100, it) }
            true
        } catch (e: Exception) {
            false
        }
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun field(hintText: String, value: String) = EditText(this).apply {
        hint = hintText
        setText(value)
        setTextColor(Color.WHITE)
        setHintTextColor(0xFF77778A.toInt())
        background = rounded(0xFF1C1C28.toInt(), 14)
        setPadding(dp(16), dp(14), dp(16), dp(14))
        setSingleLine(true)
    }

    private fun chip(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t
        setTextColor(0xFFCFC8FF.toInt())
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        setPadding(dp(14), dp(9), dp(14), dp(9))
        background = rounded(0xFF26234A.toInt(), 18)
        setOnClickListener { onClick() }
    }

    private fun toggle(t: String, on: Boolean) = Switch(this).apply {
        text = t
        isChecked = on
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
    }

    private fun lp(top: Int) = LinearLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT).apply { topMargin = dp(top) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("s", 0)
        selectedColor = prefs.getInt("color", 0xFF7C5CFF.toInt())

        urlField = field("https://api.deepseek.com", prefs.getString("url", "https://openrouter.ai/api/v1") ?: "")
        keyField = field("API-ключ", prefs.getString("key", "") ?: "")
        modelField = field("Модель", prefs.getString("model", "google/gemma-4-31b-it:free") ?: "")
        btnTextField = field("AI", prefs.getString("btnText", "AI") ?: "AI").apply {
            filters = arrayOf(InputFilter.LengthFilter(4))
        }
        soundSwitch = toggle("Звуки", prefs.getBoolean("sound", true))
        ttsSwitch = toggle("Озвучивать ответ голосом", prefs.getBoolean("tts", false))
        sizeBar = SeekBar(this).apply {
            max = 60
            progress = prefs.getInt("size", 56) - 36
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(64), dp(24), dp(24))
        }
        root.addView(label("Screen AI", 32f, Color.WHITE, true), lp(0))
        root.addView(label("ИИ-помощник, который видит твой экран и отвечает на голос или текст", 14f, 0xFF9A9AB0.toInt()), lp(6))

        // ----- provider -----
        root.addView(label("Провайдер (🆓 — есть бесплатный лимит)", 13f, 0xFFB8B8CC.toInt()), lp(28))
        val presets = listOf(
            Triple("🆓 OpenRouter", "https://openrouter.ai/api/v1", "google/gemma-4-31b-it:free"),
            Triple("🆓 Groq", "https://api.groq.com/openai/v1", "openai/gpt-oss-120b"),
            Triple("🆓 Gemini", "https://generativelanguage.googleapis.com/v1beta/openai", "gemini-3.8-flash"),
            Triple("DeepSeek", "https://api.deepseek.com", "deepseek-flash")
        )
        val providerRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        presets.forEach { (name, url, model) ->
            providerRow.addView(
                chip(name) { urlField.setText(url); modelField.setText(model) },
                LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = dp(8) }
            )
        }
        val providerScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(providerRow)
        }
        root.addView(providerScroll, lp(8))
        root.addView(label("Адрес API", 13f, 0xFFB8B8CC.toInt()), lp(20))
        root.addView(urlField, lp(8))
        root.addView(label("API-ключ", 13f, 0xFFB8B8CC.toInt()), lp(16))
        root.addView(keyField, lp(8))
        root.addView(label("Модель", 13f, 0xFFB8B8CC.toInt()), lp(16))
        root.addView(modelField, lp(8))

        // ----- avatar / look -----
        root.addView(label("Внешний вид кнопки", 13f, 0xFFB8B8CC.toInt(), true), lp(32))
        val avatarRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        avatarRow.addView(
            chip("🖼 Выбрать фото") { pickImage.launch("image/*") },
            LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT).apply { rightMargin = dp(8) }
        )
        avatarRow.addView(chip("↺ Убрать фото") {
            File(filesDir, "avatar.png").delete()
            Toast.makeText(this, "Фото убрано", Toast.LENGTH_SHORT).show()
        })
        root.addView(avatarRow, lp(10))
        root.addView(label("Надпись или эмодзи на кнопке (если без фото)", 13f, 0xFF9A9AB0.toInt()), lp(14))
        root.addView(btnTextField, lp(8))

        root.addView(label("Цвет кнопки", 13f, 0xFF9A9AB0.toInt()), lp(14))
        val colors = listOf(
            0xFF7C5CFF.toInt(), 0xFF2F80ED.toInt(), 0xFF27AE60.toInt(),
            0xFFEB5757.toInt(), 0xFFF2994A.toInt(), 0xFFE056A0.toInt()
        )
        val dots = mutableListOf<TextView>()
        val colorRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        colors.forEach { col ->
            val d = TextView(this).apply {
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                background = GradientDrawable().apply {
                    setShape(GradientDrawable.OVAL)
                    setColor(col)
                }
                text = if (col == selectedColor) "✓" else ""
            }
            d.setOnClickListener {
                selectedColor = col
                dots.forEachIndexed { i, v -> v.text = if (colors[i] == selectedColor) "✓" else "" }
            }
            dots.add(d)
            colorRow.addView(d, LinearLayout.LayoutParams(dp(40), dp(40)).apply { rightMargin = dp(10) })
        }
        root.addView(colorRow, lp(8))

        root.addView(label("Размер кнопки", 13f, 0xFF9A9AB0.toInt()), lp(16))
        root.addView(sizeBar, lp(4))

        // ----- sound -----
        root.addView(label("Звук", 13f, 0xFFB8B8CC.toInt(), true), lp(28))
        root.addView(soundSwitch, lp(10))
        root.addView(ttsSwitch, lp(10))

        val start = TextView(this).apply {
            text = "Запустить"
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(0xFF7C5CFF.toInt(), 0xFF4F8CFF.toInt())
            ).apply { cornerRadius = dp(16).toFloat() }
            setPadding(0, dp(16), 0, dp(16))
        }
        root.addView(start, lp(32))
        root.addView(
            label(
                "После запуска появится кнопка поверх экрана. Нажми её, выбери действие или задай вопрос. Кнопку можно перетаскивать.",
                13f, 0xFF77778A.toInt()
            ), lp(24)
        )

        val scroll = ScrollView(this).apply {
            setBackgroundColor(0xFF0E0E16.toInt())
            isFillViewport = true
            addView(root)
        }
        setContentView(scroll)

        start.setOnClickListener {
            prefs.edit()
                .putString("url", urlField.text.toString().trim())
                .putString("key", keyField.text.toString().trim())
                .putString("model", modelField.text.toString().trim())
                .putString("btnText", btnTextField.text.toString().trim().ifEmpty { "AI" })
                .putInt("color", selectedColor)
                .putInt("size", sizeBar.progress + 36)
                .putBoolean("sound", soundSwitch.isChecked)
                .putBoolean("tts", ttsSwitch.isChecked)
                .apply()
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Разреши показ поверх других окон и нажми снова", Toast.LENGTH_LONG).show()
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else {
                permLauncher.launch(arrayOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.POST_NOTIFICATIONS))
            }
        }
    }
}
