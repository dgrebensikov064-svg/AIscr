package com.example.screenai

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioManager
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.ToneGenerator
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import com.googlecode.tesseract.android.TessBaseAPI
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private val main = Handler(Looper.getMainLooper())
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vDisplay: VirtualDisplay? = null
    private var recognizer: SpeechRecognizer? = null
    private lateinit var bubble: View
    private var tone: ToneGenerator? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var soundOn = true
    private var ttsOn = false
    private var accent = 0xFF7C5CFF.toInt()
    private lateinit var panel: LinearLayout
    private lateinit var panelParams: WindowManager.LayoutParams
    private lateinit var input: EditText
    private lateinit var answer: TextView
    private var w = 0
    private var h = 0

    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val OVERLAY = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY

    override fun onBind(i: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startAsForeground()
        if (intent == null) { stopSelf(); return START_NOT_STICKY }
        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data")
        if (data == null) { stopSelf(); return START_NOT_STICKY }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val prefs = getSharedPreferences("s", 0)
        soundOn = prefs.getBoolean("sound", true)
        ttsOn = prefs.getBoolean("tts", false)
        accent = prefs.getInt("color", 0xFF7C5CFF.toInt())
        tone = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 70)
        tts = TextToSpeech(this) { st ->
            if (st == TextToSpeech.SUCCESS) {
                tts?.setLanguage(Locale("ru", "RU"))
                ttsReady = true
            }
        }
        setupCapture(code, data)
        setupOverlay()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val ch = "screenai"
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(ch, "Screen AI", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, ch)
            .setContentTitle("Screen AI работает")
            .setSmallIcon(android.R.drawable.ic_menu_view)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
    }

    // ---------- screen capture ----------
    private fun setupCapture(code: Int, data: Intent) {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        val p = mpm.getMediaProjection(code, data)
        projection = p
        p.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)
        val dm = resources.displayMetrics
        w = dm.widthPixels
        h = dm.heightPixels
        val r = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        reader = r
        vDisplay = p.createVirtualDisplay(
            "screenai", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, main
        )
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        val p = img.planes[0]
        val rowPad = p.rowStride - p.pixelStride * w
        val full = Bitmap.createBitmap(w + rowPad / p.pixelStride, h, Bitmap.Config.ARGB_8888)
        full.copyPixelsFromBuffer(p.buffer)
        img.close()
        return Bitmap.createBitmap(full, 0, 0, w, h)
    }

    // ---------- UI helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    private fun roundedTop(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        val f = dp(r).toFloat()
        cornerRadii = floatArrayOf(f, f, f, f, 0f, 0f, 0f, 0f)
    }

    private fun label(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = t
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

    private fun circleBtn(t: String, bgColor: Int, onClick: () -> Unit) = TextView(this).apply {
        text = t
        gravity = Gravity.CENTER
        setTextColor(Color.WHITE)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        background = GradientDrawable().apply {
            setShape(GradientDrawable.OVAL)
            setColor(bgColor)
        }
        setOnClickListener { onClick() }
    }

    private fun chip(t: String, prompt: String) = TextView(this).apply {
        text = t
        setTextColor(0xFFCFC8FF.toInt())
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setPadding(dp(14), dp(8), dp(14), dp(8))
        background = rounded(0xFF26234A.toInt(), 18)
        setOnClickListener { input.setText(prompt); ask(prompt) }
    }

    private fun beep(type: Int) {
        if (soundOn) runCatching { tone?.startTone(type, 120) }
    }

    private fun speak(t: String) {
        if (ttsOn && ttsReady) tts?.speak(t, TextToSpeech.QUEUE_FLUSH, null, "ans")
    }

    private fun clean(s: String) = s
        .replace("**", "")
        .replace("```", "")
        .replace(Regex("(?m)^#{1,6}\\s*"), "")
        .trim()

    // ---------- overlay UI ----------
    private fun setupOverlay() {
        val prefs = getSharedPreferences("s", 0)
        val size = dp(prefs.getInt("size", 56))
        val avatarFile = File(filesDir, "avatar.png")
        bubble = if (avatarFile.exists()) {
            ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setImageBitmap(BitmapFactory.decodeFile(avatarFile.absolutePath))
            }
        } else {
            TextView(this).apply {
                text = prefs.getString("btnText", "AI") ?: "AI"
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, size / dp(1) * 0.29f)
                typeface = Typeface.DEFAULT_BOLD
                background = GradientDrawable().apply {
                    setShape(GradientDrawable.OVAL)
                    setColor(accent)
                }
            }
        }
        val bp = WindowManager.LayoutParams(
            size, size, OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = w - size - dp(12)
            y = dp(220)
        }
        wm.addView(bubble, bp)

        var sx = 0
        var sy = 0
        var tx = 0f
        var ty = 0f
        var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = bp.x; sy = bp.y; tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt()
                    val dy = (e.rawY - ty).toInt()
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    if (moved) {
                        bp.x = sx + dx
                        bp.y = sy + dy
                        wm.updateViewLayout(bubble, bp)
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        beep(ToneGenerator.TONE_PROP_PROMPT)
                        showPanel(panel.visibility != View.VISIBLE)
                    }
                }
            }
            true
        }

        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedTop(0xF2141420.toInt(), 24)
            setPadding(dp(16), dp(14), dp(16), dp(16))
            visibility = View.GONE
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        header.addView(label("Screen AI", 17f, Color.WHITE, true), LinearLayout.LayoutParams(0, WRAP, 1f))
        val speaker = circleBtn(if (ttsOn) "🔊" else "🔇", 0xFF2A2A3A.toInt()) { }
        speaker.setOnClickListener {
            ttsOn = !ttsOn
            speaker.text = if (ttsOn) "🔊" else "🔇"
            if (!ttsOn) tts?.stop()
            getSharedPreferences("s", 0).edit().putBoolean("tts", ttsOn).apply()
        }
        header.addView(speaker, LinearLayout.LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(8) })
        header.addView(circleBtn("✕", 0xFF2A2A3A.toInt()) { stopSelf() }, LinearLayout.LayoutParams(dp(36), dp(36)))
        panel.addView(header)

        val chips = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(
            "✏️ Реши" to "Реши то, что на экране",
            "💡 Объясни" to "Объясни, что на экране",
            "🌐 Переведи" to "Переведи текст с экрана на русский",
            "📝 Кратко" to "Кратко перескажи текст с экрана"
        ).forEach { (t, p) ->
            chips.addView(chip(t, p), LinearLayout.LayoutParams(WRAP, WRAP).apply { rightMargin = dp(8) })
        }
        val chipScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(chips)
        }
        panel.addView(chipScroll, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        input = EditText(this).apply {
            hint = "Спроси про экран…"
            setTextColor(Color.WHITE)
            setHintTextColor(0xFF77778A.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            background = rounded(0xFF22222F.toInt(), 22)
            setPadding(dp(16), dp(10), dp(16), dp(10))
            maxLines = 3
        }
        val mic = circleBtn("🎤", 0xFF2A2A3A.toInt()) { listen() }
        val send = circleBtn("➤", accent) {
            val q = input.text.toString().trim()
            if (q.isNotEmpty()) ask(q)
        }
        val inputRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        inputRow.addView(input, LinearLayout.LayoutParams(0, WRAP, 1f))
        inputRow.addView(mic, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(8) })
        inputRow.addView(send, LinearLayout.LayoutParams(dp(44), dp(44)).apply { leftMargin = dp(8) })
        panel.addView(inputRow, LinearLayout.LayoutParams(MATCH, WRAP).apply { topMargin = dp(12) })

        answer = TextView(this).apply {
            setTextColor(0xFFEDEDF5.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setTextIsSelectable(true)
            setLineSpacing(0f, 1.15f)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            background = rounded(0xFF1B1B28.toInt(), 16)
            text = "Привет! Выбери действие или задай вопрос про то, что сейчас на экране."
        }
        val scroll = ScrollView(this)
        scroll.addView(answer)
        panel.addView(scroll, LinearLayout.LayoutParams(MATCH, (h * 0.28).toInt()).apply { topMargin = dp(12) })

        panelParams = WindowManager.LayoutParams(
            MATCH, WRAP, OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM
            softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        }
        wm.addView(panel, panelParams)
    }

    private fun showPanel(show: Boolean) {
        panelParams.flags = if (show) {
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
        } else {
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        panel.visibility = if (show) View.VISIBLE else View.GONE
        wm.updateViewLayout(panel, panelParams)
    }

    // ---------- main flow ----------
    private fun ask(q: String) {
        beep(ToneGenerator.TONE_PROP_BEEP)
        answer.text = "Читаю экран…"
        reader?.acquireLatestImage()?.close()      // сбросить старый кадр
        panel.visibility = View.INVISIBLE          // чтобы панель не попала на скриншот
        bubble.visibility = View.INVISIBLE
        main.postDelayed({
            val bmp = grab()
            panel.visibility = View.VISIBLE
            bubble.visibility = View.VISIBLE
            if (bmp == null) {
                answer.text = "Не удалось снять экран"
            } else {
                thread {
                    try {
                        val text = ocr(bmp)
                        main.post { answer.text = "Думаю…" }
                        val reply = clean(deepseek(q, text))
                        main.post { answer.text = reply; beep(ToneGenerator.TONE_PROP_ACK); speak(reply) }
                    } catch (e: Exception) {
                        main.post { answer.text = friendly(e.message ?: ""); beep(ToneGenerator.TONE_PROP_NACK) }
                    }
                }
            }
        }, 400)
    }

    private fun friendly(msg: String): String = when {
        msg.contains("Insufficient Balance") -> "На аккаунте нет денег. Выбери бесплатного провайдера на главном экране или пополни баланс."
        msg.contains("HTTP 401") || msg.contains("HTTP 403") -> "Ключ не подошёл (или провайдер недоступен в твоём регионе). Проверь ключ и адрес API."
        msg.contains("HTTP 404") -> "Модель или адрес API не найдены. Проверь поля «Адрес API» и «Модель»."
        msg.contains("HTTP 429") -> "Лимит бесплатных запросов исчерпан. Подожди немного и повтори."
        msg.contains("Unable to resolve host") -> "Нет интернета."
        else -> "Ошибка: $msg"
    }

    private fun ocr(bmp: Bitmap): String {
        val dir = File(filesDir, "tess")
        val td = File(dir, "tessdata").apply { mkdirs() }
        for (l in listOf("rus", "eng")) {
            val f = File(td, "$l.traineddata")
            if (!f.exists()) assets.open("tessdata/$l.traineddata").use { i -> f.outputStream().use { i.copyTo(it) } }
        }
        val api = TessBaseAPI()
        check(api.init(dir.absolutePath, "rus+eng")) { "Tesseract не запустился" }
        api.setImage(bmp)
        val t = api.getUTF8Text() ?: ""
        api.recycle()
        return t
    }

    private fun deepseek(q: String, screen: String): String {
        val prefs = getSharedPreferences("s", 0)
        val key = prefs.getString("key", "") ?: ""
        val model = (prefs.getString("model", "") ?: "").ifEmpty { "deepseek-flash" }
        val base = (prefs.getString("url", "") ?: "").trim().trimEnd('/').ifEmpty { "https://api.deepseek.com" }
        val messages = JSONArray()
            .put(JSONObject().put("role", "system").put("content",
                "Пользователь присылает текст, распознанный с экрана телефона (OCR, возможны ошибки), и запрос. Отвечай на языке запроса, по делу, без markdown-разметки."))
            .put(JSONObject().put("role", "user").put("content", "Текст с экрана:\n$screen\n\nЗапрос: $q"))
        val body = JSONObject().put("model", model).put("messages", messages)
        val c = URL("$base/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.setRequestProperty("Authorization", "Bearer $key")
        c.setRequestProperty("Content-Type", "application/json")
        c.doOutput = true
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val ok = c.responseCode < 400
        val s = (if (ok) c.inputStream else c.errorStream).bufferedReader().readText()
        if (!ok) throw Exception("HTTP ${c.responseCode}: $s")
        return JSONObject(s).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    // ---------- voice ----------
    private fun listen() {
        tts?.stop()
        recognizer?.destroy()
        val rec = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer = rec
        rec.setRecognitionListener(object : RecognitionListener {
            override fun onResults(r: Bundle?) {
                val t = r?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t != null) { input.setText(t); ask(t) }
            }
            override fun onError(e: Int) { answer.text = "Голос не распознан (код $e)" }
            override fun onReadyForSpeech(p: Bundle?) { answer.text = "Слушаю…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(p: Bundle?) {}
            override fun onEvent(t: Int, p: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU")
        rec.startListening(i)
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        tone?.release()
        recognizer?.destroy()
        runCatching { wm.removeView(bubble) }
        runCatching { wm.removeView(panel) }
        vDisplay?.release()
        reader?.close()
        projection?.stop()
        super.onDestroy()
    }
}
